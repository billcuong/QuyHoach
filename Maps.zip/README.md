Leaflet.Zoomify
===============

Display Zoomify tiles with Leaflet.

<a href="http://blog.thematicmapping.org/2013/06/showing-zoomify-images-with-leaflet.html">More information</a>
